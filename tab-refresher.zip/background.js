let refreshInterval = null;
let currentTabId = null;

// Update badge with countdown timer
function updateBadge(seconds) {
  if (seconds > 0) {
    chrome.action.setBadgeText({text: seconds.toString()});
    chrome.action.setBadgeBackgroundColor({color: '#007aff'});
  } else {
    chrome.action.setBadgeText({text: ''});
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'refreshTab':
      chrome.tabs.reload(request.tabId, {}, () => {
        // Notify popup that refresh completed
        chrome.runtime.sendMessage({
          action: 'tabRefreshed',
          tabId: request.tabId
        });
        sendResponse({success: true});
      });
      break;

    case 'startAutoRefresh':
      if (refreshInterval) {
        clearInterval(refreshInterval);
      }
      currentTabId = request.tabId;
      refreshInterval = setInterval(() => {
        chrome.tabs.reload(currentTabId);
      }, request.interval);
      sendResponse({success: true});
      break;

    case 'stopAutoRefresh':
      if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
        currentTabId = null;
      }
      sendResponse({success: true});
      break;

    case 'getRemainingTime':
      // Forward to popup.js
      chrome.runtime.sendMessage(
        {action: 'getRemainingTime'},
        (response) => {
          if (response && response.seconds) {
            updateBadge(response.seconds);
          }
        }
      );
      sendResponse({success: true});
      break;

    default:
      sendResponse({success: false, error: 'Unknown action'});
  }
  return true;
});
